$(".image-form").hide();

$(".payment-form").hide();

function Details(){

       $(".guide-line").hide();

       $(".query-form").hide();

       $(".image-form").show();

       $(".payment-form").show();

}