$(".image-form").hide();

$(".payment-form").hide();

function Details(){

       $(".guide-line").hide();

       $(".query-form").hide();

       $(".image-form").show();

       $(".payment-form").show();

}

jQuery(function($) {
    var dropvar;
    $.validator.addMethod("numPut", function(value){
        dropvar = value;
    });
    $.validator.addMethod("numPut", function(value){
        dropvar = value;
    });


$("#payment-form").validate({

        
    rules: {
        cardNum: {
            required: true,
            digits: true,
            minlength: 16,
            maxlength: 16,
            numPut: true,
        },
    },
    messages: {
        cardNum: {
            required: "Please enter your number",
            digits: "Please enter valid number",
            minlength: "Please enter 16 digits",
            maxlength: "Only 16 digits allowed",

        }, 
    },
    
    submitHandler: function(form) {
        form.submit();
    }
});
});
