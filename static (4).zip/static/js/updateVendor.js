$(".vendor-form").hide();
function showUpdate(){
	$(".vendor-search").hide();
	$(".vendor-form").show();
}