$(".image-form").hide();

$(".payment-form").hide();

function Details(){

       $(".guide-line").hide();

       $(".query-form").hide();

       $(".image-form").show();

       $(".payment-form").show();

}

jQuery(function($) {


    

     


$("#details-form").validate({

        
        rules: {
            
            amount: {
                required: true
            },
        },
        messages: {
            
            amount: {
                required: "Please enter the bill amount"
            },
        },
        
        submitHandler: function(form) {
            form.submit();
        }
    });


$("#payment-form").validate({

        
    rules: {
        cardNum: {
            required: true,
            digits: true,
            minlength: 16,
            maxlength: 16,
     
            
        },
       
        cvv: {
            required: true,
            digits: true,
            minlength: 3,
            maxlength: 3
        },
        validityMonth: {
            required: true

        },
        
    },
    messages: {
        cardNum: {
            required: "Please enter your number",
            digits: "Please enter valid number",
            minlength: "Please enter 16 digits",
            maxlength: "Only 16 digits allowed"

        }, 
     
        cvv: {
            required: "Please enter your number",
            digits: "Please enter valid number",
            minlength: "Please enter 3 digits",
            maxlength: "Only 3 digits allowed"

        }, 
        validityMonth: {
            required: "Please enter the validity month and year"

        },
        
    },
    
    submitHandler: function(form) {
        form.submit();
    }
});
});
