

jQuery(function($) {
    var dropvar;
    //for name validation
    $.validator.addMethod("alpha", function(value, element){

        return this.optional(element) || value == value.match(/^[a-zA-Z\s]+$/) && value != value.match(/[\s]+/) ;

    });
    $.validator.addMethod("text", function(value, element){

        return this.optional(element) || value != value.match(/[\s]+/) ;

    });
    $.validator.addMethod("identity", function(value){
        if (dropvar == "1") {
            return (value != value.match(/[\s]+/) && value == value.match(/^GMV[a-zA-Z0-9]+$/));
        }

        else if (dropvar == "2") {
            return (value != value.match(/[\s]+/) && value == value.match(/^PASS[a-zA-Z0-9]+$/));
        }

        else if (dropvar == "3") {
            return (value != value.match(/[\s]+/) && value == value.match(/^DL[a-zA-Z0-9]+$/));
        }

        else if (dropvar == "4") {
            return (value != value.match(/[\s]+/) && value == value.match(/^PAN[a-zA-Z0-9]+$/));
        }

    });
    $.validator.addMethod("dropdown", function(value){
        // print(dropdown)
        dropvar = value;
    });

    


    $("#customer-form").validate({
        
    rules: {
        name:  {
            required: true,
            alpha: true
        },
        address: {
            required: true,
            text: true
        },
        email: {
            required: true,
            email: true
        },
        number: {
            required: true,
            digits: true,
            minlength: 10,
            maxlength: 10
        },
        identity: {
            required: true,
            dropdown: true

        },
        docdetailnumber: {
            required: true,
            identity: true

        },
    },
    messages: {
        name: {
            required: "Please enter your name",
            alpha: "Alphabets and spaces only allowed"
        },
        address: {
            required: "Please enter your address",
            text: "Please enter valid address"
        },
        email: {
            required: "Please enter an email address",
            email: "Please enter a valid email address"
        },
        number: {
            required: "Please enter your number",
            digits: "Please enter valid number",
            minlength: "Please enter minimum 10 digits",
            maxlength: "Only 10 digits allowed"
        }, 
        docdetailnumber: {
            required: "Please enter your ID",
            identity: "Please enter Valid ID"
        },
        
        
    },
    submitHandler: function(form) {
        form.submit();
    }
});
});