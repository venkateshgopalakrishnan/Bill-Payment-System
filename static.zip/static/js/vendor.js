function getJson() {
	var $items = $(' #vendorName,  #vendorCompanyRegistrationNo,  #vendorType,  #vendorAddress,#vendorCountry,  #vendorState,  #vendorEmail,  #vendorContact,  #vendorWebsite,#vendorCertificateIssuedDate,  #vendorCertificateValidityDate,  #vendorEmployeesCount,#vendorCustomerCount,  #vendorYearOfEstablishment');
	var obj = {};
	$items.each(function() {
		obj[this.id] = $(this).val();
	});
	var json = JSON.stringify(obj);
	return json;
}

function registerVendor() {
	var loginData = getJson();
	var vendorContollerUrl = "http://localhost:3100/vendors/register/";
	$.ajax({
		type : "POST",
		url : vendorContollerUrl,
		data : loginData,
		contentType : "application/json",
		dataType : "json",
		success : function(response) {

			console.log(response);
			// window.location = "/dashboard.html";
		},

		error : function() {
		}

	});
}
