$(".customer-form").hide();
function showUpdate() {
	$("#cSearch").hide();
	$(".customer-form").show();
	$(".customer-details").show();
	var cid=$("#customerIdQuery").val();
	var searchContollerUrl = "http://localhost:3100/customers/"+cid;
	$.ajax({
		type : "GET",
		url : searchContollerUrl,
		dataType : "json",
		success : function(response) {
			$("#uName").val(response.customerName);
		}
	});
}

function getFalse(){
	return false;
}